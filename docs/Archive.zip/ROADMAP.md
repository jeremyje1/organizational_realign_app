# Roadmap

| Quarter | Milestone | Status |
|---------|-----------|--------|
| **Q3 2025** | MVP complete (Assessment Wizard + Analytics) | 🔄 In progress |
| **Q4 2025** | Scenario Builder + Export Reports | ⏳ Planned |
| **Q1 2026** | ML Recommendation Engine | ⏳ Planned |
| **Q2 2026** | Marketplace of pre‑built org templates | ⏳ Planned |
